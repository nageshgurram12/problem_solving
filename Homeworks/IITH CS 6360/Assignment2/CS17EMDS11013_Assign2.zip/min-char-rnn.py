"""
Minimal character-level Vanilla RNN model. Written by Andrej Karpathy (@karpathy)
BSD License
"""
import numpy as np

# Set the flag to 'pretrained' to False to load weights pretrained 
pretrained = True

# data I/O
data = open('shakespeare_train.txt', 'r').read() # should be simple plain text file
chars = list(set(data))
data_size, vocab_size = len(data), len(chars)
print('data has %d characters, %d unique.' % (data_size, vocab_size))
char_to_ix = { ch:i for i,ch in enumerate(chars) }
ix_to_char = { i:ch for i,ch in enumerate(chars) }

# hyperparameters
hidden_size = 100 # size of hidden layer of neurons
seq_length = 25 # number of steps to unroll the RNN for
learning_rate = 1e-1
num_epochs = 2
alpha = 1 # Inverse of temperature in softmax

# model parameters
Wxh = np.random.randn(hidden_size, vocab_size)*0.01 # input to hidden
Whh = np.random.randn(hidden_size, hidden_size)*0.01 # hidden to hidden
Why = np.random.randn(vocab_size, hidden_size)*0.01 # hidden to output
bh = np.zeros((hidden_size, 1)) # hidden bias
by = np.zeros((vocab_size, 1)) # output bias

def lossFun(inputs, targets, hprev):
  """
  inputs,targets are both list of integers.
  hprev is Hx1 array of initial hidden state
  returns the loss, gradients on model parameters, and last hidden state
  """
  xs, hs, ys, ps = {}, {}, {}, {}
  hs[-1] = np.copy(hprev)
  loss = 0
  # forward pass
  for t in range(len(inputs)):
    xs[t] = np.zeros((vocab_size,1)) # encode in 1-of-k representation
    xs[t][inputs[t]] = 1
    hs[t] = np.tanh(np.dot(Wxh, xs[t]) + np.dot(Whh, hs[t-1]) + bh) # hidden state
    ys[t] = np.dot(Why, hs[t]) + by # unnormalized log probabilities for next chars
    ps[t] = np.exp(ys[t]) / np.sum(np.exp(ys[t])) # probabilities for next chars
    loss += -np.log(ps[t][targets[t],0]) # softmax (cross-entropy loss)
  # backward pass: compute gradients going backwards
  dWxh, dWhh, dWhy = np.zeros_like(Wxh), np.zeros_like(Whh), np.zeros_like(Why)
  dbh, dby = np.zeros_like(bh), np.zeros_like(by)
  dhnext = np.zeros_like(hs[0])
  for t in reversed(range(len(inputs))):
    dy = np.copy(ps[t])
    dy[targets[t]] -= 1 # backprop into y. see http://cs231n.github.io/neural-networks-case-study/#grad if confused here
    dWhy += np.dot(dy, hs[t].T)
    dby += dy
    dh = np.dot(Why.T, dy) + dhnext # backprop into h
    dhraw = (1 - hs[t] * hs[t]) * dh # backprop through tanh nonlinearity
    dbh += dhraw
    dWxh += np.dot(dhraw, xs[t].T)
    dWhh += np.dot(dhraw, hs[t-1].T)
    dhnext = np.dot(Whh.T, dhraw)
  for dparam in [dWxh, dWhh, dWhy, dbh, dby]:
    np.clip(dparam, -5, 5, out=dparam) # clip to mitigate exploding gradients
  return loss, dWxh, dWhh, dWhy, dbh, dby, hs[len(inputs)-1]

def sample(h, seed_ix, n, alpha=0.01):
  """ 
  sample a sequence of integers from the model 
  h is memory state, seed_ix is seed letter for first time step
  """
  x = np.zeros((vocab_size, 1))
  x[seed_ix] = 1
  ixes = []
  for t in range(n):
    h = np.tanh(np.dot(Wxh, x) + np.dot(Whh, h) + bh)
    y = np.dot(Why, h) + by
    adj_y = y / alpha
    p = np.exp(adj_y) / np.sum(np.exp(adj_y))
    ix = np.random.choice(range(vocab_size), p=p.ravel())
    x = np.zeros((vocab_size, 1))
    x[ix] = 1
    ixes.append(ix)
  return ixes

# If pretrained flag is False, then train network here
if not pretrained:
  n, p = 0, 0
  mWxh, mWhh, mWhy = np.zeros_like(Wxh), np.zeros_like(Whh), np.zeros_like(Why)
  mbh, mby = np.zeros_like(bh), np.zeros_like(by) # memory variables for Adagrad
  smooth_loss = -np.log(1.0/vocab_size)*seq_length # loss at iteration 0
  epoch_iter = 0
  while epoch_iter < num_epochs:
    # prepare inputs (we're sweeping from left to right in steps seq_length long)
    if p+seq_length+1 >= len(data) or n == 0: 
      hprev = np.zeros((hidden_size,1)) # reset RNN memory
      p = 0 # go from start of data
      epoch_iter += 1
    inputs = [char_to_ix[ch] for ch in data[p:p+seq_length]]
    targets = [char_to_ix[ch] for ch in data[p+1:p+seq_length+1]]
  
    # sample from the model now and then
    if n % 100 == 0:
      sample_ix = sample(hprev, inputs[0], 200, alpha)
      txt = ''.join(ix_to_char[ix] for ix in sample_ix)
      print('----\n %s \n----' % (txt, ))
  
    # forward seq_length characters through the net and fetch gradient
    loss, dWxh, dWhh, dWhy, dbh, dby, hprev = lossFun(inputs, targets, hprev)
    smooth_loss = smooth_loss * 0.999 + loss * 0.001
    if n % 100 == 0: print('iter %d, loss: %f' % (n, smooth_loss)) # print progress
    
    # perform parameter update with Adagrad
    for param, dparam, mem in zip([Wxh, Whh, Why, bh, by], 
                                  [dWxh, dWhh, dWhy, dbh, dby], 
                                  [mWxh, mWhh, mWhy, mbh, mby]):
      mem += dparam * dparam
      param += -learning_rate * dparam / np.sqrt(mem + 1e-8) # adagrad update
  
    p += seq_length # move data pointer
    n += 1 # iteration counter 
else:
  a = np.load(open("char-rnn-snapshot.npz", "rb"))
  Wxh = a["Wxh"] 
  Whh = a["Whh"]
  Why = a["Why"]
  bh = a["bh"]
  by = a["by"]
  mWxh, mWhh, mWhy = a["mWxh"], a["mWhh"], a["mWhy"]
  mbh, mby = a["mbh"], a["mby"]
  hidden_size = 250
  chars, data_size, vocab_size, char_to_ix, ix_to_char = a["chars"].tolist(), a["data_size"].tolist(), a["vocab_size"].tolist(), a["char_to_ix"].tolist(), a["ix_to_char"].tolist()

def generate(input_str="", pred_next_len=50):
  """
  Generate continuation of input string for the next 'pred_next_len' chars
  """
  h = np.zeros((hidden_size,1))
  for i, char in enumerate(input_str):
    x = np.zeros((vocab_size, 1))
    if char in char_to_ix:
      x[char_to_ix[char]] = 1
    h = np.tanh(np.dot(Wxh, x) + np.dot(Whh, h) + bh)

  # We have hidden state after input str, generate continuation
  pred_str = ""
  for i in range(pred_next_len):
    y = np.dot(Why, h) + by
    p = np.exp(y) / np.sum(np.exp(y))
    ix = np.random.choice(range(vocab_size), p=p.ravel())
    pred_str += ix_to_char[ix]
    xt = np.zeros((vocab_size, 1)) # take pred y as input for next state
    xt[ix] = 1
    h = np.tanh(np.dot(Wxh, xt) + np.dot(Whh, h) + bh) # readjust hidden states
    
  return pred_str

def analyse(input_char=':'):
  """
  Analyse weight vectors for input char
  """
  ix = char_to_ix[input_char]
  x = np.zeros((vocab_size, 1))
  x[ix] = 1 # one hot representation of x
  h = np.tanh(np.dot(Wxh, x)) # activation for the x
  max_act = np.argmax(h)
  print("\n Highest activation for x: %f at postition %d" % (h[max_act], max_act))
  out_weights = Why[:,max_act]
  max_out = np.argsort(-out_weights)[0:2]
  print("\n Highest activations will occur in output in positions %d, %d" % (max_out[0], max_out[1]))
  print("\n High predicting probability for %s, %s" % (repr(ix_to_char[max_out[0]]), repr(ix_to_char[max_out[1]])))

print("\n\n ----- \n Please give input string to generate continuation: ")
input_str = input()
print(generate(input_str))

analyse(':')